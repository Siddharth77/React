import React from 'react';
import { render } from 'react-dom';
import { Example1 } from './example-1';

render(
    <Example1 />,
    document.getElementById('example-1')
);

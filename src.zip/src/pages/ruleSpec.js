import React from 'react';
import SwaggerUi, {presets} from 'swagger-ui';
import 'swagger-ui/dist/swagger-ui.css';




class RuleSpec extends React.Component {
    constructor(props) {
       super(props);
    };
    
     componentDidMount(){
       SwaggerUi({
         dom_id: '#swaggerContainer',
         url: `http://dev.api.genius.kube.t-mobile.com/ruleengine/v1/v2/api-docs?group=T-Mobile`,
         presets: [presets.apis],
       });
   
    
     }
    
    render() {
        return (
          <div id="swaggerContainer" />
        );
    }
};

export default RuleSpec;



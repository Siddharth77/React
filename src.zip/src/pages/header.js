import React from 'react';

export default props => {
  return (
    <div className="col-md-12 bgTmo header pa-5">
                <button className="t-mobile-logo"></button>
                <label className="clrWhite api ml-20">Developer API Portal</label>
                <label className="clrWhite pull-right api ml60">Welcome,John</label>
                <button className="nineDots"></button>
            </div>
  );
};
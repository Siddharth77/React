import React from 'react';
import SwaggerEditor, {plugins} from 'swagger-editor';
import 'swagger-editor/dist/swagger-editor.css';


class Error extends React.Component {
    
    
    componentDidMount(){
        window.editor = SwaggerEditor({
            dom_id: '#swagger-editor',
            layout: 'EditorLayout',
            plugins: Object.values(plugins),
            swagger2GeneratorUrl: 'https://generator.swagger.io/api/swagger.json',
            oas3GeneratorUrl: 'https://generator3.swagger.io/openapi.json',
            swagger2ConverterUrl: 'https://converter.swagger.io/api/convert',
        });
      
    }
    
    render() {
        return (
            <div id='swagger-editor'></div>
        );
    }
};

export default Error;

// export default props => {
//   return (
//     <div className="col-md-12 textCenter">
//         <button className="helpImg mt-20">Image</button>
//         <div className="mt-20 fontsize20">A space for you to manage your API specifications and share your work easily</div>
//         {/* <div className="col-md-12 home mt-20">
//             <div className="boxHome">
//                 <div className="mt35">123</div>
//                 <div>Create API Spec</div>
//             </div>
//             <div className="boxHome">
//                 <div className="mt35">123</div>
//                 <div>Import API Spec</div>
//             </div>
//             <div className="boxHome">
//                 <div className="mt35">123</div>
//                 <div>Rules Spec</div>
//             </div>
            
//         </div>     */}
//     </div>
//   );
// };
import React from 'react';
import { NavLink } from 'react-router-dom'
//import { slide as Menu } from 'react-burger-menu';

import home from './home';
import createApi from './createApi';
import ruleSpec from './ruleSpec';
import $ from 'jquery';


class sidebar extends React.Component{
  constructor(props) {
    super(props);
    this.state = {
      condition: false
    }

    this.selectedMenu = "home";
    this.currentRoute = window.location.pathname.replace('/','');
    this.handleClick = this.handleClick.bind(this)
}

handleClick(routeName) {
  // this.setState({
  //   condition: !this.state.condition
  // })
  this.selectedMenu = routeName;
  //this.currentRoute = (window.location.pathname).replace('/','');
}

render(){
  return (
    <div className="width4 bgSidebar height38">
                <div>
                    <NavLink to="home"><button className={ (this.selectedMenu == 'home') ? "homeImg active" : "homeImg" } onClick={ (e) => this.handleClick('home',e) }></button></NavLink>
                    <NavLink to="userview"><button className={ (this.selectedMenu == 'userview') ? "compassImg active" : "compassImg" } onClick={ (e) => this.handleClick('userview',e) }></button></NavLink>
                    <button className="codeImg mt-20"></button>
                    <button className="editImg mt-20"></button>
                    <button className="helpImg mt-20"></button>
                    <NavLink to="createApi"><button className="errorImg mt-20"></button></NavLink>
                    <NavLink to="ruleSpec"><button className="docErrorImg mt-20"></button></NavLink>
                </div>
    </div>
  );
};
}
export default sidebar;
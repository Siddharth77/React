import React from 'react';
import { NavLink, Redirect } from 'react-router-dom';

import createApi from './createApi';

import $ from 'jquery';

class Home extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        fields: [],
        errors: [],
        redirect: false,
        apiSpecTemplateData: [],
        specOnSubmitData : []
    };
        this.handleChange = this.handleChange.bind(this);
        this.submituserRegistrationForm = this.submituserRegistrationForm.bind(this);        
        this.renderRedirect = this.renderRedirect.bind(this);  
        this.setRedirect = this.setRedirect.bind(this);
        this.clearInput = this.clearInput.bind(this);
        this.getTemplateData = this.getTemplateData.bind(this);
        this.getDataOnTemplateName = this.getDataOnTemplateName.bind(this);
    };
    
    renderRedirect() {
        if (this.state.redirect) {
            let createApiData={
                status: 'New',
                apiSpecName: this.state.fields['apiSpecName'],
                apiSpecTemplateName: this.state.fields['apiSpecTemplateName'],
                owner: this.state.fields['owner'],
                visibility: this.state.fields['visibility'],
                openApiVerison: this.state.fields['openApiVerison'],
                apiSpec: this.state.specOnSubmitData['apiSpec']
            }
                        
            fetch('http://10.10.145.72:8092/api-portal/v1/api-specs', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(createApiData)
            })
            .then(function(resp){                
               
            })
            $('#image-gallery').modal('hide');
            // <Redirect to='/createApi'/>
            

            return <Redirect to={{
                pathname: '/createApi',
                state: { data: createApiData }
            }}/>
        }
    }

    handleChange(e){
        let fields = this.state.fields;        
        fields[e.target.name] = e.target.value;
        let errors = this.state.errors;
        
        if(e.target.value != ''){
            errors[e.target.name] = '';
        }
        this.setState({
            fields,
            errors
        });
    }

    getTemplateData(){
        let apiDropdownUrl = 'http://10.10.145.72:8092/api-portal/v1/api-templates';
        fetch(apiDropdownUrl)
            .then(response => response.json())
            .then(apiSpecTemplateName =>{
                this.setState({apiSpecTemplateData : apiSpecTemplateName})
            })
            .catch(err => {
                console.log("Error Reading apiSpecTemplate Data" + err);
            });           
    }

    setRedirect () {
        this.setState({
            redirect: true
        })
    }
    
       
    clearInput(){
            let fields = {};
            fields["apiSpecName"] = "";
            fields["owner"] = "";
            fields["visibility"] = ""; 
            fields["openApiVerison"] = ""; 
            //fields["API_Spec"] = "";
            fields["apiSpecTemplateName"] = "";            
            this.setState({fields:fields});
    }

    submituserRegistrationForm(e) {
        e.preventDefault();
        if (this.validateForm()) {
            this.getDataOnTemplateName();            
            let fields = {};
            fields["apiSpecName"] = "";
            fields["owner"] = "";
            fields["visibility"] = ""; 
            fields["openApiVerison"] = ""; 
            //fields["API_Spec"] = "";
            fields["apiSpecTemplateName"] = "";            
            //this.setState({fields:fields});
            this.setRedirect();
        }
    }
    
    getDataOnTemplateName() {
        let updateDataUrl = "10.10.145.72:8092/api-portal/v1/api-templates/"+ this.state.fields['apiSpecTemplateName'];
            fetch(updateDataUrl)
            .then(response => response.json())
            .then(json => this.setState({
                specOnSubmitData: json}))       
            .catch(err => {
                console.log("Error Reading Data" + err);
        });
    }

    validateForm(){
        let fields = this.state.fields;
        let errors = {};
        let formIsValid = true;
        
        if(!fields["apiSpecName"]){
            formIsValid = false;
            errors["apiSpecName"] = "*Please enter API Name";
        }

        // if(typeof fields["apiSpecName"] !== "undefined"){
        //     if(!fields["apiSpecName"].match(/^[a-zA-Z ]*$/)){
        //         formIsValid = false;
        //         errors["apiSpecName"] = "*Please enter alphabet characters only"
        //     }
        // }

        if(!fields["owner"]){
            formIsValid = false;
            errors["owner"] = "*Please enter owner Name";
        }

        // if(typeof fields["owner"] !== "undefined"){
        //     if(!fields["owner"].match(/^[a-zA-Z ]*$/)){
        //         formIsValid = false;
        //         errors["owner"] = "*Please enter alphabet characters only"
        //     }
        // }

        if(!fields["visibility"]){
           
            formIsValid = false;
            errors["visibility"] = "*Please select visibilty";
        }

        if(!fields["openApiVerison"]){
           formIsValid = false;
            errors["openApiVerison"] = "*Please select API Version";
        }

        // if(!fields["API_Spec"]){
        //     formIsValid = false;
        //      errors["API_Spec"] = "*Please select API Specification";
        //  }
        
         if(!fields["apiSpecTemplateName"]){
            formIsValid = false;
             errors["apiSpecTemplateName"] = "*Please select API Template";
         }
      
        this.setState({
            errors: errors
        })
        return formIsValid;
    }

    render() {
        let optionTemplate = this.state.apiSpecTemplateData.map(templateData => (
            <option value={templateData}>{templateData}</option>
        ));
       return (
           <div className="textCenter">
                <button className="helpImg mt-20">Image</button>
                <div className="mt-40 fontsize20">A space for you to manage your API specifications and share your work easily</div>
                <div className="col-md-12 home mt-20">
                    <div className="boxHome" data-target="#image-gallery"  data-toggle="modal">
                        <button className="mt35 createApiImg" onClick={this.getTemplateData}></button>
                        <div>Create API Spec</div>
                    </div>
                    <div className="boxHome" data-target="#image-gallery-import"  data-toggle="modal">
                        <button className="mt35 importApiImg"></button>
                        <div>Import API Spec</div>
                    </div>
                    <div className="boxHome">
                        <NavLink to="ruleSpec">
                        <button className="mt35 ruleSpecImg"></button>
                            <div>Rules Spec</div>
                        </NavLink>
                    </div>
                </div>


            <div className="modal fade" id="image-gallery" tabIndex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                        <form name="userRegistrationForm">
                            <div className="modal-header">
                                <label className="fontsize22 ml-22">Create an API Spec</label>
                                <button type="button" className="close" data-dismiss="modal">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <div>Enter a unique for your API documentation below and select a Template Select Non for a blank API.</div>
                                <select name="openApiVerison" className="dropdown" value={this.state.fields.openApiVerison} onChange={this.handleChange}>
                                    <option value="">Select API Version</option>
                                    <option value="openApiVerison">openApiVerison</option>
                                </select>
                                <div className="errorMsg">{this.state.errors.openApiVerison}</div>
                                
                                {/* <select name="API_Spec" className="dropdown" value={this.state.fields.API_Spec} onChange={this.handleChange}>
                                    <option value="">Select API Spec</option>
                                    <option value="apiSpec">apiSpec</option>
                                </select>
                                <div className="errorMsg">{this.state.errors.API_Spec}</div> */}
                                <select name="apiSpecTemplateName" className="dropdown" value={this.state.fields.apiSpecTemplateName} onChange={this.handleChange}>
                                <option value="">Select API Template</option>
                                {optionTemplate}
                                </select>
                                <div className="errorMsg">{this.state.errors.apiSpecTemplateName}</div>
                                <input className="dropdown" name="apiSpecName" placeholder="API Name" value={this.state.fields.apiSpecName} onChange={this.handleChange}></input>
                                    <div className="errorMsg">{this.state.errors.apiSpecName}</div>
                                <input name="owner" className="dropdown" placeholder="owner" value={this.state.fields.owner} onChange={this.handleChange}></input>
                                    <div className="errorMsg">{this.state.errors.owner}</div>
                                <select name="visibility" className="dropdown" value={this.state.fields.visibility} onChange={this.handleChange}>
                                    <option value="">Select Visibility</option>
                                    <option value="public">Public</option>
                                    <option value="private">Private</option>
                                </select>
                                <div className="errorMsg">{this.state.errors.visibility}</div>
                            </div>  
                            <div className="mt-20 pa-10">
                                {this.renderRedirect()}
                                <button id="createApi" className="submitBtn"  onClick= {this.submituserRegistrationForm}>Create API</button> 
                                <button type="button" className="cancelBtn" onClick= {this.clearInput} data-dismiss="modal">Cancel</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div className="modal fade" id="image-gallery-import">
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <form name="upload">
                                <div className="modal-header">                                    
                                    <button type="button" className="close" data-dismiss="modal">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div className="modal-body">
                                Drag and Drop to upload the API or <a href="">Browse</a>
                                </div>  
                                <div className="mt-20 pa-10">                                
                                </div>
                            </form>
                        </div>
                    </div>
                </div>  

            </div>
        );
    };
};

    
 
export default Home;
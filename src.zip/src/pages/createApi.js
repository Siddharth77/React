import React from 'react';
import SwaggerEditor, {plugins} from 'swagger-editor';
import 'swagger-editor/dist/swagger-editor.css';
import LintScore from '../pages/lintScore';


class createApi extends React.Component {
    constructor(props) {
       super(props);
       this.saveDocumentContent = this.saveDocumentContent.bind(this);
       this.publishDocumentContent = this.publishDocumentContent.bind(this);
    };
    
    componentDidMount(){
        
        window.editor = SwaggerEditor({
            dom_id: '#swagger-editor',
            layout: 'EditorLayout',
            plugins: Object.values(plugins),
            swagger2GeneratorUrl: 'https://generator.swagger.io/api/swagger.json',
            oas3GeneratorUrl: 'https://generator3.swagger.io/openapi.json',
            swagger2ConverterUrl: 'https://converter.swagger.io/api/convert',
        });
        
        if(this.props.location.state.data)
            window.localStorage.setItem("swagger-editor-content", this.props.location.state.data['apiSpec']);
      
    }

    saveDocumentContent(){
        let createApiData={
            status: 'Draft',
            apiSpecName: this.props.location.state.data['apiSpecName'],
            apiSpecTemplateName: this.props.location.state.data['apiSpecTemplateName'],
            owner: this.props.location.state.data['owner'],
            visibility: this.props.location.state.data['visibility'],
            openApiVerison: this.props.location.state.data['openApiVerison'],
            apiSpec:window.localStorage.getItem("swagger-editor-content")
        }
        
        fetch('http://10.10.145.72:8092/api-portal/v1/api-spec/'+this.props.location.state.data['apiSpecName'], {
        method: 'PUT',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(createApiData)
        })
        .then(function(resp){
            
            console.log("data inside create swagger",resp);
        })
        
    }

    publishDocumentContent(){
        let createApiData={
            status: 'Publish',
            apiSpecName: this.props.location.state.data['apiSpecName'],
            apiSpecTemplateName: this.props.location.state.data['apiSpecTemplateName'],
            owner: this.props.location.state.data['owner'],
            visibility: this.props.location.state.data['visibility'],
            openApiVerison: this.props.location.state.data['openApiVerison'],
            apiSpec:window.localStorage.getItem("swagger-editor-content")
        }
        
        fetch('http://10.10.145.72:8092/api-portal/v1/api-spec/'+this.props.location.state.data['apiSpecName'], {
        method: 'PUT',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(createApiData)
        })
        .then(function(resp){
            
            console.log("data inside create swagger",resp);
        })
    }
    
    render() {
        return (
            <div className="mb-50">
                <div className="pa-10">
                    <image className="helpImg"/>
                    <select className="bdrNone">
                        <option>TMobileDemoAPI1</option>
                    </select>
                    <select  className="bdrNone ml-20">
                        <option>1.0.0</option>
                    </select>
                    <label className="bdrNone ml10per">Created 4:21:58pm - Apr 19,2019</label>
                    <select className="pull-right bdrNone mr-25">
                        <option>Export</option>
                    </select>
                </div>
                <div className="pa-10 bdrTop">
                    
                    <button className="btnErr" style={{marginLeft: "27%"}} onClick= {this.saveDocumentContent}>Save AS</button>
                    <button className="btnErr" onClick= {this.publishDocumentContent}>Publish</button>
                    <button className="btnErr">Validaton</button>
                </div>
                <div className="ht500">
                <div id='swagger-editor'></div>
                </div>
                <LintScore />
                
            </div>
        );
    }
};

export default createApi;

// export default props => {
//   return (
//     <div className="col-md-12 textCenter">
//         <button className="helpImg mt-20">Image</button>
//         <div className="mt-20 fontsize20">A space for you to manage your API specifications and share your work easily</div>
//         {/* <div className="col-md-12 home mt-20">
//             <div className="boxHome">
//                 <div className="mt35">123</div>
//                 <div>Create API Spec</div>
//             </div>
//             <div className="boxHome">
//                 <div className="mt35">123</div>
//                 <div>Import API Spec</div>
//             </div>
//             <div className="boxHome">
//                 <div className="mt35">123</div>
//                 <div>Rules Spec</div>
//             </div>
            
//         </div>     */}
//     </div>
//   );
// };
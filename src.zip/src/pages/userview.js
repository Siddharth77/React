import React from 'react';
import { Redirect } from 'react-router'

class Userview extends React.Component {
        constructor(props) {
            super(props)
            this.state = {
                data: []
                
            }
        }

        componentDidMount() {
            /*fetch('data/userview.json')*/
            let alldataUrl = "http://10.10.145.72:8092/api-portal/v1/api-specs";
            fetch(alldataUrl)            
            .then(response => response.json())
            .then(json => this.setState({data: json}))       
            .catch(err => {
                console.log("Error Reading Data" + err);
            });
        }
        
        render(){
            return(            
            <div className="textCenter bgWhite">
                {/* <input type="text" className="searchbar col-md-11" placeholder="Search"/> */}
                <div className="scrollBar">
                <table id="userviewlist" className="mt-10">
                    <tbody>
                    <tr>
                        <th>API Spec Name</th>
                        <th>Maker ID</th>
                        <th>Maker Date & Time</th>
                        <th>Version</th>
                        <th>Status</th>
                    </tr>                    
                    {this.state.data.map((dynamicComponent) => <Userviewtablecontent componentData = {dynamicComponent}/>
                    )}
                    </tbody>
                </table>
                </div>
            </div>             
            )
        }
}

class Userviewtablecontent extends React.Component {    

    constructor(props) {
        super(props);
        this.state = {
            apiSpecName:'',
            redirect: false,
            individualData:[],
            apiSpecDet:''
        }    
        // This binding is necessary to make `this` work in the callback
        this.handleClick = this.handleClick.bind(this);
        this.renderRedirect = this.renderRedirect.bind(this);
        console.log(this.renderRedirect);
    }
    
    setRedirect(){
        this.setState ({
            redirect: true
        })
    }

    renderRedirect(){
        if(this.state.redirect){
            var individualUrl = "http://10.10.145.72:8092/api-portal/v1/api-specs/"+this.state.apiSpecName;        
            fetch(individualUrl)
            .then(response => response.json())
            .then(resultData => {
                this.setState({redirect: false});
            })     
            .catch(err => {
                console.log("Error Reading Individual Data" + err);
                console.info(err + " url: " + individualUrl);
            });

            
            return <Redirect to={{
                pathname: '/createApi',
                state: { data: this.state.apiSpecDet }
            }}/>
            
        }
    }
    
    handleClick = (apiSpecName,e) => {
        e.preventDefault();
        this.setRedirect();
        this.setState({'apiSpecName':apiSpecName});
        this.setState({'apiSpecDet':this.props.componentData});
    };    

    render() {                       
        return(
            <tr>
                {this.renderRedirect()}
                <td><a href="javascript:void(0)" onClick={(e) => this.handleClick(this.props.componentData.apiSpecName,e)}>{this.props.componentData.apiSpecName} </a></td>  
                <td>{this.props.componentData.createdBy}</td>
                <td>{this.props.componentData.createdDate}</td>
                <td>{this.props.componentData.openApiVerison}</td>
                <td>{this.props.componentData.status}</td>
            </tr>
        )
    }
}

export default Userview;




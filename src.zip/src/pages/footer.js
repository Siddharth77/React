import React from 'react';

export default props => {
  return (
      <div className="bgTmo col-md-12 pa-10 footer">
        <label className="clrWhite fontsize12 ml-20">Copyright @2019 Tech Mahindra. Confidential. All rigths reserved</label>
      </div>
  );
};




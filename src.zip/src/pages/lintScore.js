import React from 'react';
//import { render } from "react-dom";
import { Tabs } from "@yazanaabed/react-tabs";
// import Tabs from 'react-bootstrap/Tabs';
// import Tab from 'react-bootstrap/Tab';

class LintScore extends React.Component {
    constructor(props) {
        super(props);
    };

    render() {
        return (
            <div className="lintscorestyle">
                <ul>
                    <li className="clearwater">Clear Water</li>
                    <li>
                        <Tabs
                            activeTab={{
                                id: "tab1"
                            }}
                        >
                            <Tabs.Tab id="tab1" title="Compliance Error">
                                <div style={{ padding: 10, marginLeft: -140 }}>
                                    <div>
                                        <div className="row">
                                            <div className="col-md-4">Type</div>
                                            <div className="col-md-4">Description</div>
                                            <div className="col-md-4">Issue</div>
                                        </div>
                                    </div>
                                </div>
                            </Tabs.Tab>
                            <Tabs.Tab id="tab2" title="Warnings">
                                <div style={{ padding: 10, marginLeft: -140 }}>This is tab 2</div>
                            </Tabs.Tab>
                            <Tabs.Tab id="tab3" title="Recommendation">
                                <div style={{ padding: 10, marginLeft: -140 }}>This is tab 3</div>
                            </Tabs.Tab>
                        </Tabs>
                    </li>
                    <li className="search">Search</li>
                </ul>

            </div>
        );
    }
}

export default LintScore;
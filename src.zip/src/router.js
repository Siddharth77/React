import React from 'react'
import { Switch, Route, NavLink } from 'react-router-dom'
import home from './pages/home'
import createApi from './pages/createApi'
import ruleSpec from './pages/ruleSpec'
import Userview from './pages/userview'


const Router = () => (
    <Switch>
        <Route exact path='/' component={home} />
        <Route exact path='/Userview' component={Userview} />  
        <Route exact path='/home' component={home} />
        <Route exact path='/createApi' component={createApi} />
        <Route exact path='/ruleSpec' component={ruleSpec} />  
    </Switch>

)

export default Router;
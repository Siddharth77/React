import React, { Component } from 'react';
import Router from './router'

import Header from './pages/header';
import Sidebar from './pages/sidebar';
import Footer from './pages/footer';



const Navigation = (props) => <nav> 

  </nav>

class App extends Component{
   render(){
      return(
        <div className="pa-0">
            <Header />
            <Sidebar />
            <div className="adjustment">
            <Navigation />
            <Router />
            </div>
            <Footer />
        </div>
      );
   }
}
export default App;